<?php
//silence is golden
