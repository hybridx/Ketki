import React from 'react';

const Footer = () => (
    <footer className="footer">
        <span>&copy; Ketaki Clinic</span>
        <span>By Cybzilla Systems</span>
    </footer>
)


export default Footer