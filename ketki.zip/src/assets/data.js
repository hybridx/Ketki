export const reviews = [
  {
    "author_name": "Mehraj Shaikh",
    "author_url": "https://www.google.com/maps/contrib/108104026398731044569/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARAE",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-ss4ckI3Ahds/AAAAAAAAAAI/AAAAAAAAAAA/-fH-KtOnlk0/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 days ago",
    "text": "Much more Nice experience here, i treated my brother here nice treatment by injection only No cutting and no admitting, just 5 minutes process 👍No need of rest at home, just on the same day he went for job. Much more Nice experience here, i treated my brother here nice treatment by injection only No cutting and no admitting, just 5 minutes process 👍No need of rest at home, just on the same day he went for job.Very nice staff.I strongly recommend to go for this unique treatment 👌👌👍👍"
  },
  {
    "author_name": "Santosh Malu",
    "author_url": "https://www.google.com/maps/contrib/117656078286116844443/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARAM",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-gQMHOjOxzFA/AAAAAAAAAAI/AAAAAAAAAAA/F9pgomITvME/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a week ago",
    "text": "My friend treated here 6months ago by injection only nice experience here , No surgery No Stay here only injection. Now he enjoying Painfree life.Nice staffI strongly recommend treatment of Ketki Piles Clinic to the suffering patients 👌👌👍👍"
  },
  {
    "author_name": "Shivraj Devkatte",
    "author_url": "https://www.google.com/maps/contrib/111667662247000168058/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARAU",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-zUsq0s29TLU/AAAAAAAAAAI/AAAAAAAAAAA/d2M9tGlgUIg/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 days ago",
    "text": "The best Clinic for treatment of piles,fissur etcI got only injection treatment here only on OPD basis ,No operation or sharsutra here.Thanks and Best wishes to Team Ketki piles Clinic💐💐👍👍👌👌 "
  },
  {
    "author_name": "satish mundhe",
    "author_url": "https://www.google.com/maps/contrib/103448395155277650134/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARAc",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-Fjv-jeDWPYc/AAAAAAAAAAI/AAAAAAAAAAA/VCa1lOx5k2g/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a week ago",
    "text": "Good experience!! My mother was suffering from critical Piles issue.  Now it is ok,  thanks to ketki piles clinic. Treatment given only by injection No operation and no stay here👍👍👌👌"
  },
  {
    "author_name": "Santosh Sarkale",
    "author_url": "https://www.google.com/maps/contrib/118175946926069183021/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARAk",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-UlUeBDxl5Pw/AAAAAAAAAAI/AAAAAAAAAAA/3bQEQnBFTbY/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 months ago",
    "text": "Great experience !!!Having piles problem from last 4 yrs Took treatments here as this is without operation treatment.Feeling too much relief in a week period.Vast  experienced doctors team tàking care of all patients with personal attention.👌👌👍👍"
  },
  {
    "author_name": "prashant waghmare",
    "author_url": "https://www.google.com/maps/contrib/108788702593973979126/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARAs",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-xvZrwCpO7Q0/AAAAAAAAAAI/AAAAAAAAAAA/JMfNS3wOrG0/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a week ago",
    "text": "My Piles problem is cured from root one years back only by injection here....so i recommend  this treatment to every needy patient .I give 5* ratting to this clinic n their service,👌👍👌👍"
  },
  {
    "author_name": "Sandeep Gawali",
    "author_url": "https://www.google.com/maps/contrib/114665659007226497015/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARAz",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-zoaPjj7m6MY/AAAAAAAAAAI/AAAAAAAAAAA/D6CIEcbi_-A/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "2 weeks ago",
    "text": "Very Nice Treatment only by injection ,No need to take leave from duty or daily routineNice treatment without operation 👍👍👌👌My father taken treatment here now he is completely free of piles n all complains 👌👍"
  },
  {
    "author_name": "Nik",
    "author_url": "https://www.google.com/maps/contrib/109661667108841754163/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARA7",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-PgiWK-X0u-0/AAAAAAAAAAI/AAAAAAAAAAA/eUUdOQKce0g/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 months ago",
    "text": "I had chronic piles and fissure.I feel better and stress free after first injection during treatment.....Ketaki piles injection clinic provides best treatment in piles and fissure"
  },
  {
    "author_name": "Ajit Deokar",
    "author_url": "https://www.google.com/maps/contrib/108373271519858900079/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARBC",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-1h-h1O7Jk-I/AAAAAAAAAAI/AAAAAAAAAAA/ubRO9kIskEE/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a week ago",
    "text": "Ek Number !! Treatment only injection No opereation 👌👌☝️☝️"
  },
  {
    "author_name": "mangesh sarkale",
    "author_url": "https://www.google.com/maps/contrib/103169316724037228606/reviews?hl=en-IN&sa=X&ved=2ahUKEwjsoKi97sjjAhXadCsKHbh0DgkQvvQBegQIARBJ",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-mHYVJ5S6fiQ/AAAAAAAAAAI/AAAAAAAAAAA/5oVxA0GGW04/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 months ago",
    "text": "I treated here one of family member here Very Nice treatment by injection only ...No Admition No sharsutra Nice Staff 👌👌👍👍"
  },
  {
    "author_name": "Riddhi Habbu",
    "author_url": "https://www.google.com/maps/contrib/117045003052676536124/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARAE",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-vken0m5B0r0/AAAAAAAAAAI/AAAAAAAAAAA/SrvEkpY5fS0/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 months ago",
    "text": "Very Nice clinic for Piles ,Fissure etc by injection Only .No need to Admit No Operatings or ThreadReally Unique👍👍👌👌"
  },
  {
    "author_name": "Somnath Gadekar",
    "author_url": "https://www.google.com/maps/contrib/118050922388107446231/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARAL",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-eDgkiP888Ok/AAAAAAAAAAI/AAAAAAAAAAA/HvNW6Txfyp4/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 months ago",
    "text": "Nice clinic for treatment of piles , fissures.Suffering from bleeding piles n fissure from 10 years,.Got treatment here by injection only Now am ok n fine Enjoying pilesfree life 👍"
  },
  {
    "author_name": "ylg pictures",
    "author_url": "https://www.google.com/maps/contrib/101835301969835922426/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARAS",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-dljsQ_SzsNU/AAAAAAAAAAI/AAAAAAAAAAA/4jGQ_3Rh4Pk/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 weeks ago",
    "text": "Nice clinic only injection no operation no admission 👌👍"
  },
  {
    "author_name": "Suraj Pawar",
    "author_url": "https://www.google.com/maps/contrib/104975774024737232889/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARAZ",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-6Tu8xGEVigs/AAAAAAAAAAI/AAAAAAAAAAA/llOpUCNLTfY/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Very nice experience here. I got outstanding  results for Piles only by injections no need to stay here...Only Injection ☝️ Ek Number  treatment 👍"
  },
  {
    "author_name": "Ajinkya Lokhande",
    "author_url": "https://www.google.com/maps/contrib/108192389730208716047/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARAg",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-Hl0KliIRMCQ/AAAAAAAAAAI/AAAAAAAAAAA/sQiO1l-tR1s/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Ketki Piles Injection Clinic is excellent in treatment of Piles and Fisure.I took treatment of 2 years old  piles problem here by injection only.No need of stay for treatment moreover the Behaviour of team ketki is very good, committed to excellent Service👍Great!👍Great!"
  },
  {
    "author_name": "Dnyaneshwar Shinde",
    "author_url": "https://www.google.com/maps/contrib/100966892665694772670/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARAo",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-P0Uy4_HSWUc/AAAAAAAAAAI/AAAAAAAAAAA/wlw-5I6C5zw/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "3 months ago",
    "text": "Best experience no need to stay  no operation good supportive staff ...treatment only by injection"
  },
  {
    "author_name": "Rajabhau Gavali",
    "author_url": "https://www.google.com/maps/contrib/112634972787379600885/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARAv",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-ltZ5toDTfMo/AAAAAAAAAAI/AAAAAAAAAAA/VQF1A-vpT5Q/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Very nice experience  here. I got outstanding  results for Piles only by injection no need to stay here and no cutting Only Injection ☝️ Ek Number  treatment 👍👌"
  },
  {
    "author_name": "Omkar Kashid",
    "author_url": "https://www.google.com/maps/contrib/101076283849816586255/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARA2",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-AyQMcdmqbxU/AAAAAAAAAAI/AAAAAAAAAAA/0wYtsOEbePc/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Ketaki Piles Injection Clinic is the best clinic for piles treatment.I have taken treatment here by only injection.Now I am enjoying ‘piles free happy life’.Suggested to my friends also.👍  👍  😊😊👌  👌  "
  },
  {
    "author_name": "vishal bardapurkar",
    "author_url": "https://www.google.com/maps/contrib/117115374903882024687/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARA9",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-pc2QtxqMwbQ/AAAAAAAAAAI/AAAAAAAAAAA/C5mPH7LgsVI/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Ketki piles clinic is one of the best piles fissure n fistula treatment clinic I ever seen, only with injection no operation and no need of admitting here, my brother treated  here last year  for piles n fissure now he is OK n fine 👌👍👍I recommend  to go for it 👍"
  },
  {
    "author_name": "Babu Shinde",
    "author_url": "https://www.google.com/maps/contrib/102458752111850920196/reviews?hl=en-IN&sa=X&ved=2ahUKEwjs3dOGw8vjAhVDWX0KHcgJDV0QvvQBegQIARBE",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-n-CrORAquN4/AAAAAAAAAAI/AAAAAAAAAAA/eKSRFdu3X0E/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Excellent  experience here.Nice team Only injection treatment for piles, I am now enjoying piles free life by injection here.Thanks  team ketki piles!!😊😊👌👍☝"
  },
  {
    "author_name": "Prasad Tathawade",
    "author_url": "https://www.google.com/maps/contrib/101267958258874516937/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARAE",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-2T_6oTj_36I/AAAAAAAAAAI/AAAAAAAAAAA/Q08wcuJJ1hQ/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 1.0 out of 5,",
    "relative_time_description": "5 months ago",
    "text": "I am suffering from dangerous piles ..I thought that going to aurangabad ...but it is so far ..so please suggest me that will ketaki injectiom cure my piles permentaly and how much charges it takes for injection"
  },
  {
    "author_name": "Laximan Warvatte",
    "author_url": "https://www.google.com/maps/contrib/112327850696279185893/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARAL",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-ZWI_vCpkLZQ/AAAAAAAAAAI/AAAAAAAAAAA/ER3s-fr0X4Y/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Very Nice  Experience here, 100% satisfied results  only by injection 😊 No operation procedure and no admition only 5minutes 💉  Nice Doc n staff"
  },
  {
    "author_name": "shital kamble",
    "author_url": "https://www.google.com/maps/contrib/107594406056633673006/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARAS",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-8r41HExEkT8/AAAAAAAAAAI/AAAAAAAAAAA/mz-DPSFWm5w/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Best treatment for piles here only by injection , no admission or no operation. I treated my relative here who was suffering from old n cronic  piles and fissure problem from 4 years , he curred completely @ ketki piles by injection only.Ladies Doctor treats ladies patientThanks🙏 Team Ketki ,👌👍"
  },
  {
    "author_name": "Chandrakant Munde",
    "author_url": "https://www.google.com/maps/contrib/109542649940142661208/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARAa",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-FCNN5lf29P8/AAAAAAAAAAI/AAAAAAAAAAA/CgtW_oXuVgc/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Best clinic for piles treatment ever i seen , i have taken injection treatment here for my 2 years old bleeding  piles ,Now am ok n Fine 👌👍👍"
  },
  {
    "author_name": "Kishor Date",
    "author_url": "https://www.google.com/maps/contrib/116926555635769157167/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARAh",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-fOiDpNk_d0c/AAAAAAAAAAI/AAAAAAAAAAA/3g3KHHX5r-c/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "I have taken injection treatment @ketki piles this is the best centre for piles,Fissure etc treatment .I recommend this  as its without operation  and without admition☝👌👍👍"
  },
  {
    "author_name": "devanand kharde",
    "author_url": "https://www.google.com/maps/contrib/105423150862533309666/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARAo",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-6oCsiL8Znv0/AAAAAAAAAAI/AAAAAAAAAAA/NGHg-d5_Rfo/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "This clinc is the best one for treatment of piles, fissure etc without operation and without sharsutra, only injection and no need of any stay here!I strongly recommend it bcz my best friend has recovered here completely before six months ago from 2years old piles ,,👆👍👌👌✌️✌️"
  },
  {
    "author_name": "Jabbar Tamboli",
    "author_url": "https://www.google.com/maps/contrib/110648674682893166911/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARAv",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-e0J59Nyjb6g/AAAAAAAAAAI/AAAAAAAAAAA/ifSY5_U-4nk/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "The best clinic for piles treatment ,i have treated my relative here for dangerous piles problem from 5 years with injection only,No Admition No operation No Ksharsutra Only Injection .Very very nice Experience here, I Strongly suggest Ketki for Excellent treatment by injection only 👍👍👌👌"
  },
  {
    "author_name": "pravin vajire",
    "author_url": "https://www.google.com/maps/contrib/106874689786402669679/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARA3",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-qg_8SkhftOg/AAAAAAAAAAI/AAAAAAAAAAA/ztTWuIuqJaQ/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Very Excellent Treatment for Piles fissure etc without operation only by injectionNice staff"
  },
  {
    "author_name": "Shivkumar Biradar",
    "author_url": "https://www.google.com/maps/contrib/102869256539879300403/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARA-",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-X0oiuaS_fZU/AAAAAAAAAAI/AAAAAAAAAAA/KBAJvGdeL6E/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Ketki clinic is the best centre  for Guaranteed treatment of piles by 💉  injection  only ,  No operation  No need to  stay there 😊👍👌"
  },
  {
    "author_name": "Saurabh Sutar",
    "author_url": "https://www.google.com/maps/contrib/112111321390936012110/reviews?hl=en-IN&sa=X&ved=2ahUKEwje1JCq68jjAhXIR30KHchFBncQvvQBegQIARBF",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-qWc5MWMVVjs/AAAAAAAAAAI/AAAAAAAAAAA/coYeLUk6Pgg/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "9 months ago",
    "text": "This is the best treatment for piles without operation n without Ksharsutra and more specifically without any stay there, my father is now free from 5 year old piles problem.Thanks and warm wishes to the team of Ketki piles injection  clinic"
  },
  {
    "author_name": "Ritesh Sunil Pawar",
    "author_url": "https://www.google.com/maps/contrib/107879406239030957901/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARAE",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-HidgiK8Zb8Y/AAAAAAAAAAI/AAAAAAAAAAA/ZHiLLjqJbHI/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Ketaki piles injection is the only  best way-solution to enjoy piles free life. Six months  ago I completed my piles injection teatment@ketki haddapar clinic and suggested number of friends of Latur n Nanded also for this unique treatment.without operation and without any admition i got painless inj here 👌👍👍"
  },
  {
    "author_name": "Pramod Koli",
    "author_url": "https://www.google.com/maps/contrib/105093583667849892883/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARAL",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-0Yf2H1DuQYw/AAAAAAAAAAI/AAAAAAAAAAA/bA2iu7HXM2Q/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Am a RTO employee suffering from Severe bleeding piles ptoblem (up n down)  since 12 years which was not cured anywhere but when I taken ketki clinics injection treatment now Im free from bleeding n my pile masses also dropped out by injection only.No surgery No Threads ,👍👌 Only injection"
  },
  {
    "author_name": "Shivkumar Deshmukh",
    "author_url": "https://www.google.com/maps/contrib/117301974807398856095/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARAT",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-Fr_C3a5fnd8/AAAAAAAAAAI/AAAAAAAAAAA/ReoWuazF7bE/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Excellent clinic for complete piles treatment with injection only without admit and without operation !!!!!I recommend to Grab this unique n excellent option only available ,"
  },
  {
    "author_name": "Shivkumar Biradar",
    "author_url": "https://www.google.com/maps/contrib/102869256539879300403/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARAa",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-X0oiuaS_fZU/AAAAAAAAAAI/AAAAAAAAAAA/KBAJvGdeL6E/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Ketki clinic is the best centre  for Guaranteed treatment of piles by 💉  injection  only ,  No operation  No need to  stay there 😊👍👌"
  },
  {
    "author_name": "Saurabh Sutar",
    "author_url": "https://www.google.com/maps/contrib/112111321390936012110/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARAh",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-qWc5MWMVVjs/AAAAAAAAAAI/AAAAAAAAAAA/coYeLUk6Pgg/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "9 months ago",
    "text": "This is the best treatment for piles without operation n without Ksharsutra and more specifically without any stay there, my father is now free from 5 year old piles problem.Thanks and warm wishes to the team of Ketki piles injection  clinic"
  },
  {
    "author_name": "bhaskar kendre",
    "author_url": "https://www.google.com/maps/contrib/115955200362378985334/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARAp",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-m3ikf18rAQ0/AAAAAAAAAAI/AAAAAAAAAAA/3SQ6zbP0Qy8/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "This is a very nice clinic where my friend was treated a year back who is now free from his severe  pain , bleeding and Burning during motion problem, i have suggested many of other frends to have this only injection treatment instead of Operation or sharsutra etc, It needs  only 10 min to spend in ketki clinic for Injection treatment ,👆👌👍👍"
  },
  {
    "author_name": "Bhanudas Mule",
    "author_url": "https://www.google.com/maps/contrib/101819701142004865514/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARAx",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-BxaaL2I7Y9A/AAAAAAAAAAI/AAAAAAAAAAA/RR3jPhn0sv4/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Two years ago my friend Suresh Recovered  completely  from his dangerous  problem of Bleeding Piles only by injection @ ketki Piles Clinic Hadapsar ,Pune. Till today he enjoying pilesfree life. I have suggested  number of my friends to have this treatment to the needy 👌👌"
  },
  {
    "author_name": "Shivsamb Kapse",
    "author_url": "https://www.google.com/maps/contrib/107464466026463091758/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARA4",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-eS7UrP7TznE/AAAAAAAAAAI/AAAAAAAAAAA/M2-Cz0bp1v4/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "No. 1 clinic .I completed  my treatment here for my piles problem of 5yrs  only by injection  I got 100% relief from my bleed piles and large external and internal piles only with injection. Doctor and staff is much more  friendly Thanks Dr. 🙏👍👌👌"
  },
  {
    "author_name": "sukhdev shitole",
    "author_url": "https://www.google.com/maps/contrib/104574672877099477577/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARBA",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-A6hZksnoIko/AAAAAAAAAAI/AAAAAAAAAAA/OWWipBSuEm0/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "My friend taken injection treatment here by injection only (without operation n without admtting) he was suffering from piles with severe pain and burning since 5years ,treated at number of doctors but no result,Now after injection at ketki piles he ok n Fine👌👌"
  },
  {
    "author_name": "Anil Chaudhari",
    "author_url": "https://www.google.com/maps/contrib/107231212732422935885/reviews?hl=en-IN&sa=X&ved=2ahUKEwiwoLX5w8vjAhUZdCsKHfqcCucQvvQBegQIARBH",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-bxlQF4oBtyU/AAAAAAAAAAI/AAAAAAAAAAA/-G2bIjnUHIM/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Am a Suhana (Praveen Masalewale) Employee like my other co- employees I also taken piles injection treatment here for my piles problem since 2009 , now am 100% free from all piles related problems and suggested number of my friends for this treatment 👌👌👍👍"
  },
  {
    "author_name": "Tanaji Mule",
    "author_url": "https://www.google.com/maps/contrib/114605994707679493516/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARAE",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-83Rf2jgYFHw/AAAAAAAAAAI/AAAAAAAAAAA/GwTyJoCEmKI/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "8 months ago",
    "text": "Hi I Tanaji, Ketki piles injection clinic is the best way solution to enjoy piles free life. Two years ago I completed my piles injection treatment @Latur and suggested number of friends for this unique treatment. Without operation and without  any Admition I got painless inj here!! 👌👍👍"
  },
  {
    "author_name": "Sunil biradar",
    "author_url": "https://www.google.com/maps/contrib/111777997238911493481/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARAM",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-I5BhN58M8dM/AAAAAAAAAAI/AAAAAAAAAAA/Pg6yurq20TQ/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "5 months ago",
    "text": "Only injection no operation no need of stay here , nice clinic for piles treatment 👌  👍  "
  },
  {
    "author_name": "Abhay Khidse",
    "author_url": "https://www.google.com/maps/contrib/104837209055898754561/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARAT",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-uHxoPZk7WTQ/AAAAAAAAAAI/AAAAAAAAAAA/hB-xBNGgf1I/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Excelent ejection treatment 👌👍No operation !No Addmition !!Only injection !!!👍👍👍"
  },
  {
    "author_name": "datta deshpande",
    "author_url": "https://www.google.com/maps/contrib/100150694311346579332/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARAa",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-MOoDPNxyGi4/AAAAAAAAAAI/AAAAAAAAAAA/95Tdqb4oCzU/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "My close relative who was operated two years back has again got the piles problem back only in a year then we treated this case at ketki nine months back n now my relative is ok &amp; Fine ,Ketki treats piles  patient only by INJECTION 👌👍 without Cutting and more imp  without any stay in clinic ,Being belonging to Medico field I strongly Recommend to Go4This👌👍"
  },
  {
    "author_name": "Jivan Surywanshi",
    "author_url": "https://www.google.com/maps/contrib/107160095006872774642/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARAi",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-7iqvStKXiQ8/AAAAAAAAAAI/AAAAAAAAAAA/ghoMb0JvMe0/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Very Nice clinic for treatment of piles without operation n without ksharsutra only by injection"
  },
  {
    "author_name": "Raj Salunke",
    "author_url": "https://www.google.com/maps/contrib/111787351091568052347/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARAp",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-bgDSv3zQntE/AAAAAAAAAAI/AAAAAAAAAAA/t7lUbB8UT1Q/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "8 months ago",
    "text": "I got Best treatment to my excessive bleeding piles my problem was3 years old. Got only injection here without cutting or admitting,only on opd basis I have treated here much fluently and moreover painless injection treatment....I strongly recommend to go for it,,🙏"
  },
  {
    "author_name": "Bharat Bhosale",
    "author_url": "https://www.google.com/maps/contrib/114349499716967586824/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARAw",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-ezlEjpiof-Q/AAAAAAAAAAI/AAAAAAAAAAA/lTN1noyDCZI/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "This is unique treatment  only by injection without any admission or operation, I enjoying  a happy life due to this injction treatment for my Piles. Thanks  team Ketki Piles...."
  },
  {
    "author_name": "Vinayak Sangekar",
    "author_url": "https://www.google.com/maps/contrib/117210774717373131576/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARA3",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-xjdTNSy2X-k/AAAAAAAAAAI/AAAAAAAAAAA/W8rcDevHVWo/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Ketki Piles clinic is number one clinic for piles.1year before  my brother recovered here for 4 years old piles n fissure problem . He had severe Bleeding problem which was instantly stopped with injection here.Vina Operation  Vina Admition Faqt Injection 👌👍👍"
  },
  {
    "author_name": "Swara Kshirsagar",
    "author_url": "https://www.google.com/maps/contrib/106244962075052538805/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARA_",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-O28Xv1WoYbc/AAAAAAAAAAI/AAAAAAAAAAA/XnA9iyxRqnE/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Very nice clinic , my friend has taken injection treatment here, now she is OK n Fine,"
  },
  {
    "author_name": "Vijay Patane",
    "author_url": "https://www.google.com/maps/contrib/103503854165103232432/reviews?hl=en-IN&sa=X&ved=2ahUKEwjq_Z6XxcvjAhUKb30KHW-EA78QvvQBegQIARBG",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-yhUvjvH3YQs/AAAAAAAAAAI/AAAAAAAAAAA/nqXbHQxH7fM/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "5 months ago",
    "text": "Nice clinic for piles treatment  only by injection  no operation"
  },
  {
    "author_name": "mohan biradar",
    "author_url": "https://www.google.com/maps/contrib/100704004161525631394/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARAE",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-Ke4aohFcNb0/AAAAAAAAAAI/AAAAAAAAAAA/5cGgr6bItWA/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "No.1 for piles treatment No cut Only injection, 6 months back injection given to my brother in law, now he is ok n fine 🏃‍♂️👌👍"
  },
  {
    "author_name": "Vishnu Jadhav",
    "author_url": "https://www.google.com/maps/contrib/113019604136498973212/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARAL",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-iUk34qK3mGU/AAAAAAAAAAI/AAAAAAAAAAA/KNGsLwfWH90/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Excellent centre for treatment of piles n fissure etc without operations and without addimition 👌👍"
  },
  {
    "author_name": "abhi gaik",
    "author_url": "https://www.google.com/maps/contrib/104978100482349923321/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARAS",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-O7snOtFr0Sg/AAAAAAAAAAI/AAAAAAAAAAA/CsSCRmtrI3s/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "As i was  suffering from piles from long time and after getting injection treatment i  got good result .thank you ."
  },
  {
    "author_name": "Supriya Gaikwad",
    "author_url": "https://www.google.com/maps/contrib/109630976710471114425/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARAZ",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-cnoIwn8jlKE/AAAAAAAAAAI/AAAAAAAAAAA/RSIETFfEYkE/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Excellent experience here. Nice doc"
  },
  {
    "author_name": "Tanaji Vhalgade",
    "author_url": "https://www.google.com/maps/contrib/118121382171111826120/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARAg",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-DhBMlhuvyJw/AAAAAAAAAAI/AAAAAAAAAAA/04Em7DZHF-g/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Treatment is without operation without admition i have taken injection treatment here and now i really filling good ,,👍👌"
  },
  {
    "author_name": "Prathamesh Nalawade",
    "author_url": "https://www.google.com/maps/contrib/116513344426877793643/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARAn",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-V32gIMlnogk/AAAAAAAAAAI/AAAAAAAAAAA/alk79Ou2wUU/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "My mom suffering from cronic Fissure n Bleeding piles problem got only injection treatment here now she is completely Free from this n enjoying Happy life👌👍👌👍😊😊"
  },
  {
    "author_name": "Sunil Mudhale",
    "author_url": "https://www.google.com/maps/contrib/116020005088578103346/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARAu",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-zKQob6YSAYk/AAAAAAAAAAI/AAAAAAAAAAA/Od1AdRz7OoA/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "This clinic is the best one for treatment of piles ....Best one clinic is this....😊"
  },
  {
    "author_name": "Madhav Malkari",
    "author_url": "https://www.google.com/maps/contrib/101965458811911612765/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARA1",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-6KtsxwrygSw/AAAAAAAAAAI/AAAAAAAAAAA/XHSyUzKISsg/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 4.0 out of 5,",
    "relative_time_description": "9 months ago",
    "text": "Very nice experience ,no operations no admition only 5min procedure ,fast treatment"
  },
  {
    "author_name": "Naina Chikane",
    "author_url": "https://www.google.com/maps/contrib/105391126242328171928/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARA8",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-oAGlTTavUWY/AAAAAAAAAAI/AAAAAAAAAAA/spJYrH6JStQ/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "9 months ago",
    "text": "Its very miraculous treatment ever i heard,Painless without any stay i have got the superb treatment over here, thanks Ketki Clinic being solving my a year old problem !!"
  },
  {
    "author_name": "rohan yadav",
    "author_url": "https://www.google.com/maps/contrib/113442738141738627335/reviews?hl=en-IN&sa=X&ved=2ahUKEwiGzdT-xcvjAhVCcCsKHc0pDMEQvvQBegQIARBD",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-Pj2X7ff8qng/AAAAAAAAAAI/AAAAAAAAAAA/pVUNuqJR1VA/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Nice clinic for treated clinic . I have treated my 5 yrs old problem here only by injection here...."
  },
  {
    "author_name": "Parmeshawar Birajdar",
    "author_url": "https://www.google.com/maps/contrib/110712998808796075577/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARAE",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-6bQudWL_axI/AAAAAAAAAAI/AAAAAAAAAAA/Oc5027otItI/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Nice clinic for treatment of piles , I cured my 1 years  old problem of piles here by injection only, no operation only injection 👌👍"
  },
  {
    "author_name": "laxman gaikwad",
    "author_url": "https://www.google.com/maps/contrib/115477644156505266676/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARAL",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-eG3qsvRoFXE/AAAAAAAAAAI/AAAAAAAAAAA/XwrRDo4GemA/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Nice clinic for treatment of Piles by injection only 👌👍"
  },
  {
    "author_name": "Asha Raut",
    "author_url": "https://www.google.com/maps/contrib/110493290994579417160/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARAS",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-II4tZjn3oIM/AAAAAAAAAAI/AAAAAAAAAAA/mIfpArw3xi4/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Nice clinic for piles  treatment by injection only"
  },
  {
    "author_name": "vishnukant biradar",
    "author_url": "https://www.google.com/maps/contrib/110368219296849590386/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARAZ",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-BS7QpP7i2e4/AAAAAAAAAAI/AAAAAAAAAAA/WY-raykq8Lc/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a year ago",
    "text": "Trusted &amp;  Excellent treatment in Ketki Piles Clinic.. 100% Non Surgical treatment. Cured in very less time.  100% effective &amp; Aurvedic treatment being provided by the well experienced Dr. Definitely recommend for piles, fishers patients. Trusted clinic, Go for it. :)"
  },
  {
    "author_name": "Pooja Jogdand",
    "author_url": "https://www.google.com/maps/contrib/102917935263964188517/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARAh",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-4jmWygL3P6E/AAAAAAAAAAI/AAAAAAAAAAA/u-Bg-EcniJY/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a year ago",
    "text": "Ketki piles is the best clinc to get cure from piles.  It is very simple and easy treatment . It gives 100 percent result in one week. It is completely ayurvedic treatment.  No side-effects occurs during treatment."
  },
  {
    "author_name": "Sheetal Shelkar",
    "author_url": "https://www.google.com/maps/contrib/109881012519629993055/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARAo",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-VNjzj1Shyl8/AAAAAAAAAAI/AAAAAAAAAAA/6XXRZPMRaSg/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Best clinic is very well"
  },
  {
    "author_name": "Muzeeb Shaikh",
    "author_url": "https://www.google.com/maps/contrib/100651575024868451437/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARAv",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-70i9fIORuuc/AAAAAAAAAAI/AAAAAAAAAAA/OnM6H7lMMnQ/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Good treatment without operation"
  },
  {
    "author_name": "Raj Shaikh",
    "author_url": "https://www.google.com/maps/contrib/104566888432314210954/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARA2",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-Ujgrl9jc3fw/AAAAAAAAAAI/AAAAAAAAAAA/iTEXKslgzS8/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a year ago",
    "text": "This centre provides pure ayurvedic  treatment (Non Recurrent)  without operation or cutting or ksharsutra,, moreover without Admitting patients,,, Grab this comparatively painless piles injection treatment..... for Piles, fissure n fistula 👍👌"
  },
  {
    "author_name": "sanket daundkar",
    "author_url": "https://www.google.com/maps/contrib/105642205868172327390/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARA9",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-JMimY1VWje8/AAAAAAAAAAI/AAAAAAAAAAA/06vbtT66jHg/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a year ago",
    "text": "Ketki piles injection clinic is the best centre for piles, fissure n fistula patients ....no operation or cut just with injection my friend dinesh got rid form cronic piles....now he enjoys piles free life.... I suggest to go for it"
  },
  {
    "author_name": "Dinesh Bhore",
    "author_url": "https://www.google.com/maps/contrib/111017009248369119017/reviews?hl=en-IN&sa=X&ved=2ahUKEwiT-8GxzcbjAhUKA3IKHYByAjQQvvQBegQIARBE",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-TfRolbYJUas/AAAAAAAAAAI/AAAAAAAAAAA/u5puP-_Z8LE/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a year ago",
    "text": "Ketki piles injection clinic is the best centre for piles, fissure n fistula patients ....no operation or cut just with injection my friend Sanket got rid form cronic piles....now he enjoys piles free life.... I suggest to go for it"
  },
  {
    "author_name": "Dinesh Bhore",
    "author_url": "https://www.google.com/maps/contrib/111017009248369119017/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARAE",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-TfRolbYJUas/AAAAAAAAAAI/AAAAAAAAAAA/u5puP-_Z8LE/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a year ago",
    "text": "Ketki piles injection clinic is the best centre for piles, fissure n fistula patients ....no operation or cut just with injection my friend Sanket got rid form cronic piles....now he enjoys piles free life.... I suggest to go for it"
  },
  {
    "author_name": "Anusaya Vajire",
    "author_url": "https://www.google.com/maps/contrib/106284952170502170552/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARAL",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/--PEQLbMIp1M/AAAAAAAAAAI/AAAAAAAAAAA/akmRt4o3uKM/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a year ago",
    "text": "Ketki piles injection is one of the Best injection of piles. &amp; Best treatment for piles."
  },

  {
    "author_name": "haree Tupsundre",
    "author_url": "https://www.google.com/maps/contrib/112455416792784053580/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARAZ",
    "language": "en",
    "profile_photo_url": "https://lh6.ggpht.com/-V7wF7CAMMbE/AAAAAAAAAAI/AAAAAAAAAAA/gPH5R6Nu3vg/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "So good"
  },
  {
    "author_name": "ashwini jadhav",
    "author_url": "https://www.google.com/maps/contrib/108054308921891637205/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARAg",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-5b4wBNrhioY/AAAAAAAAAAI/AAAAAAAAAAA/GbZsx5173tw/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "a week ago",
    "text": "Sadhi ani sopi treatment ahe Yethe faqt injection dware Upchaar kela jato; chirphad wegere nahi tasech admit honyachi sudha garaj nahi....Khupch mast Upchar ani mast staff!!"
  },
  {
    "author_name": "Kishor Pan",
    "author_url": "https://www.google.com/maps/contrib/115857462562493347045/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARAn",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-DqXtni9Etlw/AAAAAAAAAAI/AAAAAAAAAAA/0Xgq8G_GCiE/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "केतकी पाइल्स हा उपचार खूपच चांगला आहे . जास्त टेन्शन घेयचं नाही थोडा खर्च होतो पण १०० % उपचार होतो येवढा एकच उपचार ग्यारिंटीचा आहे.         ह्या  आजाराला लाजू नका याचा उपचार केतकी पाइल्स मध्ये केला जातो. मी लाजून लाजून शेवटी येथे येऊन इंजेक्शन घेतलो व आज १५ वर्ष जून्या अशा भयंकर त्रासातून १००%मुक्त जीवन जगतआहेत.धन्यवाद केतकी🙏"
  },
  {
    "author_name": "Arun Landge",
    "author_url": "https://www.google.com/maps/contrib/103189116090315625895/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARAv",
    "language": "en",
    "profile_photo_url": "https://lh3.ggpht.com/-aweV1vESW3M/AAAAAAAAAAI/AAAAAAAAAAA/KiDWx34--MY/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "मला 3 वर्षांपासुन भगंदरचा भयंकर त्रास होता. माझे 2 वर्षांपूर्वी ऑपरेशन झाले होते पण त्याने उलट माझा ञास वाढला. अधिक प्रमाणात पू स्ञऊ लागले. मग मि 3 महिन्यापूर्वी मिञाच्या सांगण्यानुसार केतकी पाईल्स क्लिनिक येथे येऊन  फक्त इंजेक्शन घेऊन आज मी भगंदरच्या त्रासातून 100% मुक्त झालेलो आहे.मी व माझा परिवार केतकी पाईल्स  चा आभार मानतो,  धन्यवाद 🙏🙏I have had horrible trouble for 3 years. I had an operation two years ago, but instead I grew up. There was a lot of scope for them. Then, 3 months ago, according to the advice of Mishya, only at the Keetaki Pilates clinic, I have been 100% free from the frustration of the kjunder.Thanks a lot for me and my family, thank you"
  },
  {
    "author_name": "Narsing Gund",
    "author_url": "https://www.google.com/maps/contrib/104999021601044377115/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARA3",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/--9-ZDkpjAbU/AAAAAAAAAAI/AAAAAAAAAAA/d7njAJ3FrSc/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "6 months ago",
    "text": "Mulyad Chya upchara sathi ek number dwakhana ahe, Mazya patient la 10 varshya pasun mulvyad Cha khup bhayankar tras hota ketki clinic yethe 1 varshya purvi injection ghevun atta mazha patient ekdum ok ahe 👍👌"
  },
  {
    "author_name": "Samsher shaikh",
    "author_url": "https://www.google.com/maps/contrib/100994664508053628181/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARA-",
    "language": "en",
    "profile_photo_url": "https://lh4.ggpht.com/-oa-57P1Dlig/AAAAAAAAAAI/AAAAAAAAAAA/K6VWravqK0g/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "7 months ago",
    "text": "Mere Abba ka 15 saal purana ekdum danger mulvyad ki shikayat  jo kahi par bhi thik nhi ho rahi thi o ketki k injection se abhi ekdum OK hai...Allah ka Shukriya jo hume  ketki clinic Ki raah dikakar iss musibat se humeshya ke liye free kiya...Shukriya. . ."
  },
  {
    "author_name": "Shaikh Anu",
    "author_url": "https://www.google.com/maps/contrib/104468204820761575217/reviews?hl=en-IN&sa=X&ved=2ahUKEwiu3urLxsvjAhUKSX0KHROoDMAQvvQBegQIARBF",
    "language": "en",
    "profile_photo_url": "https://lh5.ggpht.com/-W5NnLH4xnEA/AAAAAAAAAAI/AAAAAAAAAAA/HJbzbW6cGoA/s40-c0x00000000-cc-rp-mo/photo.jpg",
    "rating": "Rated 5.0 out of 5,",
    "relative_time_description": "4 months ago",
    "text": "Super clinic  in pune"
  }
];
