export const userIsOnMobile = () => (window.screen.width <= 699);
